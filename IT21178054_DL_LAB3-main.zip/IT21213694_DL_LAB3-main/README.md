# IT21178054_DL_LAB3
This repository is about deep learning practical 3 that done in practical session. 
